// @/components/Layout/index.js
import React, { useState, useEffect } from 'react'
import Head from 'next/head'
import Sidebar from './Sidebar';
import MenuBarMobile from './MenuBarMobile';
import SearchPopup from '../SearchPopup'


export default function Layout({ pageTitle, children }) {
    // Concatenate page title (if exists) to site title
    let titleConcat = "Responsive Sidebar Example";
    if (pageTitle) titleConcat = pageTitle + " | " + titleConcat;

    const [showSearch, setShowSearch] = useState(false);

    useEffect(() => {
        if (showSearch) {
            console.log('Search popup is now displayed');
        }
    }, [showSearch]);

    // Mobile sidebar visibility state
    const [showSidebar, setShowSidebar] = useState(false);

    const toggleSearch = () => {
        setShowSearch(!showSearch);
    };

    return (
        <>
            <Head>
                <title>{titleConcat}</title>
            </Head>
            <div className="min-h-screen">
                <div className="flex">
                    <MenuBarMobile setter={setShowSidebar} />
                    <Sidebar show={showSidebar} setter={setShowSidebar} toggleSearch={toggleSearch} className="sidebar" />
                    {/* Conditionally render the search popup */}
                    {showSearch && <SearchPopup onClose={toggleSearch} />}
                    <div className="flex flex-col flex-grow w-screen md:w-full min-h-screen">
                        {children}
                    </div>
                </div>
            </div>
        </>
    )
}