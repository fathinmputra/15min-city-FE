// components/Walkthrough.js
import React from 'react';
import Joyride, { ACTIONS, EVENTS, STATUS } from 'react-joyride';

const Walkthrough = ({ onEnd }) => {
  const [run, setRun] = React.useState(true);

  const steps = [
    {
      target: 'body',
      content: 'Welcome to the 15 Minutes Surabaya! This guide will walk you through the main features of the site.',
      placement: 'center',
      disableBeacon: true, // Ensure the beacon doesn't show up for the first step
    },
    {
      target: '.map',
      content: 'This is the map showing the user location and nearby places.',
      placement: 'top',
    },
    {
      target: '.sidebar',
      content: 'This is the sidebar where you can access different categories and search for places.',
      placement: 'right',
    },
    {
      target: '.searchmode',
      content: 'Pilihlah mode transport yang kalian inginkan',
      placement: 'right',
    },
    {
      target: '.searchbar',
      content: 'Masukkan lokasi yang ingin kalian cari atau klik "Lokasi Saat Ini"',
      placement: 'right',
    },
    {
      target: '.categorystatus',
      content: 'Bagian ini akan menunjukkan jumlah fungsi sosial yang ada dan menunjukkan apakah daerah ini merupakan kota 15 menit atau bukan',
      placement: 'right',
    },
    {
      target: '.border',
      content: 'Garis biru ini menunjukkan batasan 15 menit dari lokasi yang kalian masukkan',
      placement: 'top',
    },
    {
      target: '.fungsisosialmarker',
      content: 'Setiap pin fungsi sosial dapat kalian klik dan akan muncul informasi tambahan',
      placement: 'top',
    },
    // Add more steps as needed
  ];

  const handleJoyrideCallback = (data) => {
    const { status, action } = data;
    const finishedStatuses = [STATUS.FINISHED, STATUS.SKIPPED];

    if (finishedStatuses.includes(status)) {
      setRun(false);
      if (onEnd) onEnd();
    }
  };

  return (
    <div className="fixed inset-0 z-50">
      <Joyride
        steps={steps}
        run={run}
        continuous
        scrollToFirstStep
        showSkipButton
        callback={handleJoyrideCallback}
        styles={{
          options: {
            zIndex: 10000,
          },
        }}
      />
    </div>
  );
};

export default Walkthrough;
