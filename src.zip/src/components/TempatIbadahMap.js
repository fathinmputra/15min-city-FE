"use client"

import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import Leaflet from 'leaflet';
import 'leaflet/dist/leaflet.css';
import Papa from 'papaparse';

const TempatIbadahMap = () => {

  const [userLocation, setUserLocation] = useState(null);
  const [error, setError] = useState(null);
  const [worshipData, setWorshipData] = useState([]);
  const [loading, setLoading] = useState(true);

  // Define the category name mapping
  const categoryNames = {
    halte: 'Halte',
    pendidikan: 'Pendidikan',
    hiburan: 'Tempat Hiburan',
    kesehatan: 'Kesehatan',
    perkantoran: 'Perkantoran',
    perdagangan: 'Perdagangan',
    hidup: 'Tempat Ibadah',
    kuliner: 'Kuliner'
  };
  
  const currLocIcon = Leaflet.divIcon({
    html: `<div class="relative flex h-6 w-6 z-50">
        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
        <span class="relative inline-flex h-6 w-6 items-center justify-center">
          <span class="absolute inline-flex h-5 w-5 rounded-full bg-white"></span>
          <span class="relative inline-flex h-4 w-4 rounded-full bg-red-500"></span>
        </span>
      </div>`,
    iconSize: [64,64],
    iconAnchor: [64/2, 64],
    className: 'currLoc'
  });

  const worshipIcon = new Leaflet.Icon({
    iconUrl: '/worshipIcon.svg',
    iconSize: [48,48],
    iconAnchor: [48/2, 48],
    className: 'worshipIcon',
    popupAnchor: [0, -50]
  });

  useEffect(() => {
    const fetchWorshipData = async () => {
      try {
        // Fetch the CSV file from the public directory
        const response = await fetch('/15mincity.csv');
        const reader = response.body.getReader();
        const result = await reader.read();
        const decoder = new TextDecoder('utf-8');
        const csvData = decoder.decode(result.value);

        // Parse CSV data
        Papa.parse(csvData, {
          header: true,
          complete: (result) => {
            // Filter data where kategori is 'kesehatan'
            const filteredData = result.data.filter(row => row.kategori === 'hidup');
            console.log('Filtered CSV data:', filteredData);
            setWorshipData(filteredData);
          },
          error: (error) => {
            console.error('Error parsing CSV data:', error);
          }
        });
      } catch (error) {
        console.error('Error fetching worship data:', error);
      }
    };

    fetchWorshipData();
  }, []);

  useEffect(() => {
    let geoOptions = {
      enableHighAccuracy: true,
      timeout: 20000,
      maximumAge: 60 * 60 * 24
    };

    const geoSuccess = (position) => {

      setUserLocation({
        lat: position.coords.latitude,
        lng: position.coords.longitude
      });
    }

    const geoFailure = (err) => {
      setError(err.message);
    }

    navigator.geolocation.getCurrentPosition(geoSuccess, geoFailure, geoOptions);
  }, []);

  const getPosition = (worship) => {
    const lat = parseFloat(worship.latitude);
    const lon = parseFloat(worship.longitude);
    return [lat, lon];
  };

  return (
    <MapContainer
      center={[-7.250445, 112.768845]}
      zoom={13}
      scrollWheelZoom={false}
      style={{height: '100%'}}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
      />
      {userLocation && (
        <Marker
          position={userLocation}
          icon={currLocIcon}
        ></Marker>
      )}
      {worshipData.map((worship, index) => (
        <Marker key={index} position={getPosition(worship)} icon={worshipIcon}>
          <Popup>
            <div className="w-32">
              <div className="font-bold break-words">{worship.name || 'Unknown Office'}</div>
              <div className="inline-block p-2 mt-2 rounded text-right font-semibold" style={{ backgroundColor: 'rgba(0, 144, 76, 0.2)', color: '#00904C' }}>
                {categoryNames[worship.kategori]}
              </div>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  )
}

export default TempatIbadahMap