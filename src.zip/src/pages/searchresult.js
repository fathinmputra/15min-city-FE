import React from 'react'
import Main from '@/components/Main'

export default function KesehatanPage() {
    return <Main title="Search Result Page" category="searchresult"/>
}