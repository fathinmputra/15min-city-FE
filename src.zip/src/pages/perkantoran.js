import React from 'react'
import Main from '@/components/Main'

export default function PerkantoranPage() {
    return <Main title="Perkantoran Page" category="perkantoran"/>
}
