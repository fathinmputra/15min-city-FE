import React from 'react'
import Main from '@/components/Main'

export default function TempatHiburanPage() {
    return <Main title="Tempat Hiburan Page" category="tempathiburan"/>
}
