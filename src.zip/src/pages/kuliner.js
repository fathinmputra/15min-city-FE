import React from 'react'
import Main from '@/components/Main'

export default function PerdaganganPage() {
    return <Main title="Kuliner Page" category="kuliner"/>
}
