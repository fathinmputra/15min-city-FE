import React from 'react'
import Main from '@/components/Main'

export default function PendidikanPage() {
    return <Main title="Pendidikan Page" category="pendidikan"/>
}
