import React from 'react'
import Main from '@/components/Main'

export default function KesehatanPage() {
    return <Main title="Kesehatan Page" category="kesehatan"/>
}
