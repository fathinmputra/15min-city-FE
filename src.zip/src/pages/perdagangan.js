import React from 'react'
import Main from '@/components/Main'

export default function PerdaganganPage() {
    return <Main title="Perdagangan Page" category="perdagangan"/>
}
