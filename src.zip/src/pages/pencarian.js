import React from 'react'
import Main from '@/components/Main'

export default function PencarianPage() {
    return <Main title="Pencarian Page" category=""/>
}
