// @/pages/index.js
import React from 'react'
import Main from '@/components/Main'

export default function HomePage() {
  return <Main title="Home Page" category=""/>
}
